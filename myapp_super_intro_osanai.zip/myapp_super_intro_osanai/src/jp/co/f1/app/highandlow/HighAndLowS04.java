/*
 *プログラム名：High＆LowゲームStep4
 *プログラムの説明：キーボードから「h」を入力した場合は「Highを選択しました。」と表示させ、
 *                  「l]を入力した場合は「Lowを選択しました。」と表示する。
 *作成者：小山内 滉貴
 *作成日：2024年4月11日
 */

package jp.co.f1.app.highandlow;

import java.util.Scanner;

public class HighAndLowS04 {

	public static void main(String[] args) {
		//キーボード入力の準備
		Scanner sc=new Scanner(System.in);
		
		//キーボードから入力された文字を格納する変数
		String select;
		
		//1～9の範囲でランダムな数値を生成し、代入する
		int leftCard=(int)(Math.random()*9)+1;

		//ゲームタイトル表示
		System.out.println("***************");
		System.out.println("* High ＆ Low *");
		System.out.println("***************");
		System.out.println();

		//[問題表示]と表示
		System.out.println("   [問題表示]");

		//トランプのような絵柄を用いて、ランダムな数値を左側の表示(ランダムな数値はleftCardに格納している)
		System.out.println("*****     *****");
		System.out.println("*   *     * * *");
		System.out.println("* "+leftCard+" *     * * *");
		System.out.println("*   *     * * *");
		System.out.println("*****     *****");
		
		//キーボード入力処理
		System.out.print("High or Low ?(h/l) > ");
		select=sc.nextLine();
		
		//キーボード入力の結果
		if(select.equals("h")) {
			//キーボードに「h」を入力した場合の処理
			System.out.println("→Highを選択しました。");
		} else {
			//キーボードに「l」を入力した場合の処理
			System.out.println("→Lowを選択しました。");
		}
		System.out.println();


		//ゲーム終了時のメッセージを表示
		System.out.println("--ゲーム終了--");
		
		//Scannerクラスのclose
		sc.close();

	}

}
