/*
 *プログラム名：High＆LowゲームStep2
 *プログラムの説明：1～9の範囲でランダムな数値を1つ取得し、表示する。
 *作成者：小山内 滉貴
 *作成日：2024年4月11日
 */

package jp.co.f1.app.highandlow;

public class HighAndLowS02 {

	public static void main(String[] args) {
		//1～9の範囲でランダムな数値を生成し、代入する
		int leftCard=(int)(Math.random()*9)+1;
		
		//ゲームタイトル表示
		System.out.println("***************");
		System.out.println("* High ＆ Low *");
		System.out.println("***************");
		System.out.println();
		
		//ランダムな数値の表示(ランダムな数値はleftCardに格納している)
		System.out.println("ランダム数値："+leftCard);
		System.out.println();
		
		//ゲーム終了時のメッセージを表示
		System.out.println("--ゲーム終了--");
	}

}
