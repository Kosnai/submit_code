/*
 *プログラム名：High＆LowゲームStep1
 *プログラムの説明：ゲームタイトルとゲーム終了時のメッセージを表示する。
 *作成者：小山内 滉貴
 *作成日：2024年4月11日
 */

package jp.co.f1.app.highandlow;

public class HighAndLowS01 {

	public static void main(String[] args) {
		//ゲームタイトル表示
		System.out.println("***************");
		System.out.println("* High ＆ Low *");
		System.out.println("***************");
		System.out.println();

		//ゲーム終了時のメッセージを表示
		System.out.println("--ゲーム終了--");

	}

}
