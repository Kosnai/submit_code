/*
 *プログラム名：High＆LowゲームStep6
 *プログラムの説明：このプログラムは伏せられたカードの数が、
 *                  表示されているカードの数よりも大きいか小さいかを予想するゲームです。
 *                  最初に1枚は表示されていて、1枚は伏せられている計2枚のカードが表示されます。
 *                  表示された後、大きいか小さいか問われますので、大きいと予想したら「h」を入力、
 *                  小さいと予想した場合は「l」を入力して下さい。
 *                  その後、回答が表示されます。
 *                  また、正解した方のみゲームを続行できます。
 *作成者：小山内 滉貴
 *作成日：2024年4月11日
 */

package jp.co.f1.app.highandlow;

import java.util.Scanner;

public class HighAndLowS07 {

	public static void main(String[] args) {
		//キーボード入力の準備
		Scanner sc=new Scanner(System.in);

		//キーボードから入力された文字を格納する変数
		String select;

		//左側のカードと右側のカードの数値を比較した結果を格納する変数
		String result;

		//ゲームタイトル表示
		System.out.println("***************");
		System.out.println("* High ＆ Low *");
		System.out.println("***************");
		System.out.println();

		//無限ループ
		while(true) {
			//1～9の範囲でランダムな数値を生成し、代入する
			int leftCard=(int)(Math.random()*9)+1;//左側のカード
			int rightCard=(int)(Math.random()*9)+1;//右側のカード

			//[問題表示]と表示
			System.out.println("   [問題表示]");

			//トランプのような絵柄を用いて、ランダムな数値を左側の表示(ランダムな数値はleftCardに格納している)
			System.out.println("*****     *****");
			System.out.println("*   *     * * *");
			System.out.println("* "+leftCard+" *     * * *");
			System.out.println("*   *     * * *");
			System.out.println("*****     *****");

			//キーボード入力処理
			System.out.print("High or Low ?(h/l) > ");
			select=sc.nextLine();

			//キーボード入力の結果
			if(select.equals("h")) {
				//キーボードに「h」を入力した場合の処理
				System.out.println("→Highを選択しました。");
			} else {
				//キーボードに「l」を入力した場合の処理
				System.out.println("→Lowを選択しました。");
			}
			System.out.println();

			//[結果表示]と表示
			System.out.println("   [結果表示]");

			//右側のカードにランダムな数値を表示する(ランダムな数値はrightCardに格納している)
			System.out.println("*****     *****");
			System.out.println("*   *     *   *");
			System.out.println("* "+leftCard+" *     * "+rightCard+" *");
			System.out.println("*   *     *   *");
			System.out.println("*****     *****");

			//右側のカードと左側のカードのHigh・Low判定
			if(leftCard<rightCard) {
				//左側のカードよりも右側のカードの数値が大きい場合の処理
				result="h";
			} else if(leftCard>rightCard) {
				//左側のカードよりも右側のカードの数値が小さい場合の処理
				result="l";
			} else {
				//左側のカードと右側のカードの数値が同じ場合の処理
				result = select;
			}

			//カードの数値のHigh・Low判定とユーザーが選択した予想の比較
			if(result.equals(select)) {
				//resultとselectの値が同じだった場合の処理
				System.out.println("→You Win!");
			} else {
				//resultとselectの値が同じでない場合の処理
				System.out.println("→You Lose...");
				
				//無限ループ終了
				break;
			}
			System.out.println();
		}

		//ゲーム終了時のメッセージを表示
		System.out.println();
		System.out.println("--ゲーム終了--");

		//Scannerクラスのclose
		sc.close();
	}

}
