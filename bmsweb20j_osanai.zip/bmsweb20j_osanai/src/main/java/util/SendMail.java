package util;

/*
 * プログラム名：SendMail
 * プログラムの説明：メール全般の処理を行うプログラム。
 *                   このプログラムで購入した書籍情報を任意のメールアドレスに送信する。
 * 作成者：小山内滉貴
 * 作成日：2024/05/21
 */

import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import bean.Book;

public class SendMail {

	public void mailMainPart(String Userid, ArrayList<Book> list) {
		//合計金額を格納する変数
		int total = 0;
		String listDisplay = "";

		for (int i = 0; i < list.size(); i++) {
			listDisplay += list.get(i).getIsbn() + "　" + list.get(i).getTitle() + " " + list.get(i).getPrice() + "円\n";
			total += list.get(i).getPrice();
		}

		try {
			Properties props = System.getProperties();

			// SMTPサーバのアドレスを指定（今回はxserverのSMTPサーバを利用）
			props.put("mail.smtp.host", "sv5215.xserver.jp");
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.starttls.enable", "true");
			props.put("mail.smtp.port", "587");
			props.put("mail.smtp.debug", "true");

			Session session = Session.getInstance(
					props,
					new javax.mail.Authenticator() {
						protected PasswordAuthentication getPasswordAuthentication() {
							//メールサーバにログインするメールアドレスとパスワードを設定
							return new PasswordAuthentication("test.sender@kanda-it-school-system.com",
									"kandaSender202208");
						}
					});

			MimeMessage mimeMessage = new MimeMessage(session);

			// 送信元メールアドレスと送信者名を指定
			mimeMessage.setFrom(
					new InternetAddress("test.sender@kanda-it-school-system.com", "書籍管理システム", "iso-2022-jp"));

			// 送信先メールアドレスを指定（ご自分のメールアドレスに変更）
			mimeMessage.setRecipients(Message.RecipientType.TO, "k_osanai@brain-tr.co.jp");

			// メールのタイトルを指定
			mimeMessage.setSubject("書籍購入完了のお知らせ", "iso-2022-jp");

			// メールの内容を指定
			mimeMessage.setText(Userid + "様\n\n" +
					"本のご購入ありがとうございます。\n" +
					"以下の内容でご注文を受け付けましたので、ご連絡致します。\n\n" +
					listDisplay + "合計金額" + total + "円\n\nまたのご利用よろしくお願いします。", "iso-2022-jp");

			// メールの形式を指定
			mimeMessage.setHeader("Content-Type", "text/plain; charset=iso-2022-jp");

			// 送信日付を指定
			mimeMessage.setSentDate(new Date());

			// 送信します
			Transport.send(mimeMessage);

			// 送信成功
			System.out.println("送信に成功しました。");

		} catch (Exception e) {
			// e.printStackTrace();
			System.out.println("送信に失敗しました。\n" + e);
		}
	}
}
