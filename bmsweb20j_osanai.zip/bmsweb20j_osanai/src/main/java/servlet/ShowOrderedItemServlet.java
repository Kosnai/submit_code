package servlet;

/*
 * プログラム名：ShowOrderedItemtServlet
 * プログラムの説明：購入した書籍のユーザー名、書籍のタイトル、日付を表示するプログラム。
 * 作成者：小山内滉貴
 * 作成日：2024/05/21
 */

import java.io.IOException;
import java.util.ArrayList;

import bean.OrderedItem;
import dao.OrderedItemDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/ShowOrderedItemServlet")
public class ShowOrderedItemServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//エラーメッセージとcmdを格納する変数
		String errorMessage = null;
		String errorCmd = null;

		try {
			//OrderedItemDAOクラスのオブジェクトを生成
			OrderedItemDAO orderedItemDao = new OrderedItemDAO();

			//OrderedItemDAOのselectAllメソッドを呼び出す
			ArrayList<OrderedItem> list = orderedItemDao.selectAll();

			//リクエストスコープに"ordered_list"という名前で登録
			request.setAttribute("ordered_list", list);

		} catch (Exception e) {
			/*
			 * DB接続エラー
			 */

			//エラーメッセージを設定
			errorMessage = "DB接続エラーの為、購入状況確認は出来ません。";

			//errorCmdに値を登録
			errorCmd = "logout";
		} finally {
			if (errorCmd == null) {
				//showOrderedItem.jspにフォワードする
				request.getRequestDispatcher("/view/showOrderedItem.jsp").forward(request, response);
			} else {
				//リクエストスコープにエラーメッセージを登録する
				request.setAttribute("error_message", errorMessage);

				//リクエストスコープにcmdを登録する
				request.setAttribute("cmd", errorCmd);

				//error.jspへフォワードする
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}

	}
}
