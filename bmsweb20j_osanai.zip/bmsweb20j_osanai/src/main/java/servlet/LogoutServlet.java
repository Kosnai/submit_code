package servlet;

/*
 * プログラム名：LogoutServlet
 * プログラムの説明：ログアウト処理を行うプログラム。
 *                   セッション情報をクリアした後、ログイン画面に遷移する。
 * 作成者：小山内滉貴
 * 作成日：
 */

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/LogoutServlet")
public class LogoutServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//セッション情報をクリア
		HttpSession session = request.getSession();
		session.invalidate();

		//リクエストスコープにエラーメッセージを登録する
		request.setAttribute("message", "ログアウトしました");

		//login.jspへフォワードする
		request.getRequestDispatcher("/view/login.jsp").forward(request, response);
	}

}
