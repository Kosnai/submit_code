package servlet;

/*
 * プログラム名：BuyConfirmServlet
 * プログラムの説明：書籍の購入に関する処理を行うプログラム。
 *                   書籍を購入した際には、こちらのファイルからメール送信メソッドが呼び出され、送信される。
 * 作成者：小山内滉貴
 * 作成日：2024/05/21
 */

import java.io.IOException;
import java.util.ArrayList;

import bean.Book;
import bean.Order;
import bean.User;
import dao.BookDAO;
import dao.OrderDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import util.SendMail;

@SuppressWarnings("unchecked")
@WebServlet("/BuyConfirmServlet")
public class BuyConfirmServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//エラーメッセージとcmdを格納する変数
		String errorMessage = null;
		String errorCmd = null;

		//セッションオブジェクト作成
		HttpSession session = request.getSession();

		//セッションから"user"のUserオブジェクトを取得
		User user = (User) session.getAttribute("user");

		//セッション切れの場合の処理
		if (user == null) {
			//エラーメッセージを設定
			errorMessage = "セッション切れの為、購入は出来ません。";

			//errorCmdに値を登録
			errorCmd = "logout";

			return;
		}

		//セッションから"order_list"を取得
		ArrayList<Order> order_list = (ArrayList<Order>) session.getAttribute("order_list");

		ArrayList<Book> list = new ArrayList<Book>();

		try {
			//BookDAOとOrderDAOのオブジェクトを生成
			BookDAO bookDao = new BookDAO();
			OrderDAO orderDao = new OrderDAO();

			if (order_list == null || order_list.size() == 0) {
				//エラーメッセージを設定
				errorMessage = "カートの中に何も無かったので購入は出来ません。";

				//errorCmdに値を登録
				errorCmd = "menu";

				return;
			}

			for (int i = 0; i < order_list.size(); i++) {
				//selectByIsbnメソッド(BookDAO)を呼び出す
				Book book = bookDao.selectByIsbn(order_list.get(i).getIsbn());

				//selectAllメソッド(OrderDAO)を呼び出す
				orderDao.selectAll(order_list.get(i));

				//listに書籍情報を追加
				list.add(book);
			}

			//リクエストスコープに"book_list"という名前で登録
			request.setAttribute("book_list", list);

			//SendMailのオブジェクトを生成
			SendMail sendMail = new SendMail();
			//メール送信
			sendMail.mailMainPart(user.getUserid(), list);

			//セッションの"order_list"情報をクリアする
			session.setAttribute("order_list", null);
		} catch (Exception e) {
			/*
			 * DB接続エラー
			 */

			//エラーメッセージを設定
			errorMessage = "DB接続エラーの為、購入は出来ません。 ";

			//errorCmdに値を登録
			errorCmd = "logout";
		} finally {
			if (errorCmd == null) {
				//buyConfirm.jspにフォワードする
				request.getRequestDispatcher("/view/buyConfirm.jsp").forward(request, response);
			} else {
				//リクエストスコープにエラーメッセージを登録する
				request.setAttribute("error_message", errorMessage);

				//リクエストスコープにcmdを登録する
				request.setAttribute("cmd", errorCmd);

				//error.jspへフォワードする
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}

	}
}
