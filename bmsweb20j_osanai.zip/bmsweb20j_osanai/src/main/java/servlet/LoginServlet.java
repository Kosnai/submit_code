package servlet;

/*
 * プログラム名：LoginServlet
 * プログラムの説明：ログイン処理を行うプログラム。
 *                   ユーザーIDとパスワードの両方が一致した場合にのみ、メニュー画面に遷移する。
 * 作成者：小山内滉貴
 * 作成日：2024/05/21
 */

import java.io.IOException;

import bean.User;
import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//エラーメッセージとcmdを格納する変数
		String errorMessage = null;
		String errorCmd = null;

		try {
			//ユーザーが入力したuseridとpasswordを取得する
			String userid = request.getParameter("user");
			String password = request.getParameter("password");

			//セッションオブジェクト作成
			HttpSession session = request.getSession();

			//UserDAOクラスのオブジェクトを生成
			UserDAO userDao = new UserDAO();

			//selectByUserメソッドを呼び出す
			User user = userDao.selectByUser(userid, password);

			//エラー判別処理
			if (user.getUserid() == null || user.getPassword() == null) {

				//エラーメッセージを設定
				errorMessage = "入力データが間違っています。";

				//errorCmdに値を登録
				errorCmd = "";

				return;
			}

			//セッションへデータを登録
			session.setAttribute("user", user);

			//ユーザー用クッキー生成(ユーザーID)
			Cookie userCookie = new Cookie("userid", userid);
			userCookie.setMaxAge(3600 * 24 * 5);//有効期限の設定
			response.addCookie(userCookie);

			//ユーザー用クッキー生成(パスワード)
			Cookie passwordCookie = new Cookie("password", password);
			passwordCookie.setMaxAge(3600 * 24 * 5);//有効期限の設定
			response.addCookie(passwordCookie);

		} catch (Exception e) {
			/*
			 * DB接続エラー
			 */

			//エラーメッセージを設定
			errorMessage = "DB接続エラーの為、ログインは出来ません。";

			//errorCmdに値を登録
			errorCmd = "logout";
		} finally {
			if (errorCmd == null && errorMessage == null) {
				//menu.jspにフォワードする
				request.getRequestDispatcher("/view/menu.jsp").forward(request, response);
			} else if (errorCmd.equals("logout")) {
				//リクエストスコープにエラーメッセージを登録する
				request.setAttribute("error_message", errorMessage);

				//リクエストスコープにcmdを登録する
				request.setAttribute("cmd", errorCmd);

				//error.jspへフォワードする
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			} else {
				//リクエストスコープにエラーメッセージを登録する
				request.setAttribute("message", errorMessage);

				//login.jspへフォワードする
				request.getRequestDispatcher("/view/login.jsp").forward(request, response);
			}
		}

	}

}
