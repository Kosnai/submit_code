package servlet;

/*
 * プログラム名：UpdateServlet
 * プログラムの説明：ユーザーが選択した書籍情報を更新するプログラム。
 *                   書籍タイトルと価格は変更可能だが、ISBNは変更できない。
 * 作成者：小山内滉貴
 * 作成日：2024/05/21
 */

import java.io.IOException;

import bean.Book;
import dao.BookDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/UpdateServlet")
public class UpdateServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//エラーメッセージとcmdを格納する変数
		String errorMessage = null;
		String errorCmd = null;

		try {
			//BookDAOクラスのオブジェクトを生成
			BookDAO bookDao = new BookDAO();

			//画面から入力情報を受け取る処理
			String isbn = request.getParameter("isbn");
			String title = request.getParameter("title");
			String price = request.getParameter("price");

			//変更対象のisbnが存在しているかどうかを判断するbookクラスの変数objbook
			Book objBook = bookDao.selectByIsbn(isbn);

			//エラー判別処理
			if (objBook.getIsbn() == null) {
				/*
				 * isbn関連のエラー
				 */

				//エラーメッセージを設定
				errorMessage = "更新対象の書籍が存在しない為、書籍更新処理は行えませんでした。 ";

				//errorCmdに値を登録
				errorCmd = "list";

				return;

			} else if (title.equals("")) {
				/*
				 * title関連のエラー
				 */

				//エラーメッセージを設定
				errorMessage = "タイトルが未入力の為、書籍更新処理は行えませんでした。";

				//errorCmdに値を登録
				errorCmd = "list";

				return;

			} else if (price.equals("")) {
				/*
				 * price関連のエラー
				 */

				//エラーメッセージを設定
				errorMessage = "価格が未入力の為、書籍更新処理は行えませんでした。 ";

				//errorCmdに値を登録
				errorCmd = "list";

				return;

			}
			//更新後の書籍情報を格納するBookオブジェクトを生成
			Book book = new Book();

			book.setIsbn(isbn);
			book.setTitle(title);
			book.setPrice(Integer.parseInt(price));

			//Bookオブジェクトに格納された書籍データでデータベース更新
			bookDao.update(book);

		} catch (NumberFormatException e) {
			/*
			 * price関連のエラー
			 */

			//エラーメッセージを設定
			errorMessage = "価格の値が不正の為、書籍更新処理は行えませんでした。 ";

			//errorCmdに値を登録
			errorCmd = "list";

		} catch (Exception e) {
			/*
			 * DB接続エラー
			 */

			//エラーメッセージを設定
			errorMessage = "DB接続エラーの為、書籍更新処理は行えませんでした。";

			//errorCmdに値を登録
			errorCmd = "logout";

		} finally {
			if (errorCmd == null) {
				//ListServlet.javaへフォワードする
				request.getRequestDispatcher("/ListServlet").forward(request, response);
			} else {
				//リクエストスコープにエラーメッセージを登録する
				request.setAttribute("error_message", errorMessage);

				//リクエストスコープにcmdを登録する
				request.setAttribute("cmd", errorCmd);

				//error.jspへフォワードする
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}
