package servlet;

/*
 * プログラム名：DeleteServlet
 * プログラムの説明：ユーザーが選択した書籍情報の削除を行うプログラム。
 * 作成者：小山内滉貴
 * 作成日：2024/05/21
 */

import java.io.IOException;

import dao.BookDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/DeleteServlet")
public class DeleteServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//エラーメッセージとcmdを格納する変数
		String errorMessage = null;
		String errorCmd = null;

		try {
			//BookDAOクラスのオブジェクトを生成
			BookDAO bookDao = new BookDAO();

			//画面から送信されるisbnを取得する
			String isbn = request.getParameter("isbn");

			//書籍情報があるかどうかを判別する条件式
			if (bookDao.selectByIsbn(isbn).getIsbn() == null) {
				//エラーメッセージを設定
				errorMessage = "削除対象の書籍が存在しない為、書籍削除処理は行えませんでした。 ";

				//errorCmdに値を登録
				errorCmd = "list";

				return;
			}

			//書籍情報を削除
			bookDao.delete(isbn);

		} catch (Exception e) {
			/*
			 * DB接続エラー
			 */

			//エラーメッセージを設定
			errorMessage = "DB接続エラーの為、書籍削除処理は行えませんでした。";

			//errorCmdに値を登録
			errorCmd = "logout";

		} finally {
			if (errorCmd == null) {
				//ListServlet.javaへフォワードする
				request.getRequestDispatcher("/ListServlet").forward(request, response);
			} else {
				//リクエストスコープにエラーメッセージを登録する
				request.setAttribute("error_message", errorMessage);

				//リクエストスコープにcmdを登録する
				request.setAttribute("cmd", errorCmd);

				//error.jspへフォワードする
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}

	}
}
