package servlet;

/*
 * プログラム名：InsertIntoCartServlet
 * プログラムの説明：ユーザーが購入する予定の書籍情報を表示するプログラム。
 * 作成者：小山内滉貴
 * 作成日：2024/05/21
 */

import java.io.IOException;
import java.util.ArrayList;

import bean.Book;
import bean.Order;
import bean.User;
import dao.BookDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@SuppressWarnings("unchecked")
@WebServlet("/InsertIntoCartServlet")
public class InsertIntoCartServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//エラーメッセージとcmdを格納する変数
		String errorMessage = null;
		String errorCmd = null;

		//セッションオブジェクト作成
		HttpSession session = request.getSession();

		//セッションから"user"のUserオブジェクトを取得
		User user = (User) session.getAttribute("user");

		//セッション切れの場合の処理
		if (user == null) {
			//エラーメッセージを設定
			errorMessage = "セッション切れの為、カートに追加出来ません。 ";

			//errorCmdに値を登録
			errorCmd = "logout";

			return;
		}

		//画面から送られてきたisbnのパラメータ取得
		String isbn = request.getParameter("isbn");

		try {
			//BookDAOクラスのオブジェクトを生成
			BookDAO bookDao = new BookDAO();

			//selectByIsbnメソッドを呼び出す
			Book book = bookDao.selectByIsbn(isbn);

			//リクエストスコープに登録
			request.setAttribute("Book", book);

			//Orderのインスタンスを生成
			Order order = new Order();

			//isbn,userid,数量を設定
			order.setUserid(user.getUserid());
			order.setIsbn(isbn);
			order.setQuantity(1);//固定

			//セッションから"order_list"のOrderオブジェクトを取得
			ArrayList<Order> list = (ArrayList<Order>) session.getAttribute("order_list");

			//セッションから"order_list"のOrderオブジェクトを取得でない場合の処理
			if (list == null) {
				list = new ArrayList<Order>();
			}

			//listにorderを追加
			list.add(order);

			//セッションスコープに"order_list"という名前で登録
			session.setAttribute("order_list", list);
		} catch (Exception e) {
			/*
			 * DB接続エラー
			 */

			//エラーメッセージを設定
			errorMessage = "DB接続エラーの為、カートに追加は出来ません。";

			//errorCmdに値を登録
			errorCmd = "logout";
		} finally {
			if (errorCmd == null) {
				//insertIntoCart.jspにフォワードする
				request.getRequestDispatcher("/view/insertIntoCart.jsp").forward(request, response);
			} else {
				//リクエストスコープにエラーメッセージを登録する
				request.setAttribute("error_message", errorMessage);

				//リクエストスコープにcmdを登録する
				request.setAttribute("cmd", errorCmd);

				//error.jspへフォワードする
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}
