package servlet;

/*
 * プログラム名：DetailServlet
 * プログラムの説明：書籍の詳細情報を取得し、画面から送信されたcmdを元に処理を行うプログラム。
 * 作成者：小山内滉貴
 * 作成日：2024/05/21
 */

import java.io.IOException;

import bean.Book;
import dao.BookDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/DetailServlet")
public class DetailServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//エラーメッセージとcmdを格納する変数
		String errorMessage = null;
		String errorCmd = null;

		//画面から送信されるisbnとcmdを取得する
		String cmd = request.getParameter("cmd");
		String isbn = request.getParameter("isbn");

		try {
			//BookDAOクラスのオブジェクトを生成
			BookDAO bookDao = new BookDAO();

			//登録する書籍情報を格納するBookオブジェクトを生成し、データを取得
			Book book = bookDao.selectByIsbn(isbn);

			/*
			 * エラー処理
			 */
			if (book.getIsbn() == null) {
				//エラーメッセージを設定
				if (cmd.equals("detail")) {

					//検索エラー
					errorMessage = "表示対象の書籍が存在しない為、詳細情報は表示できませんでした。";

				} else if (cmd.equals("update")) {

					//更新エラー
					errorMessage = "更新対象の書籍が存在しない為、変更画面は表示できませんでした。";

				}
				//errorCmdに値を登録
				errorCmd = "list";

				return;
			}

			//リクエストスコープに登録
			request.setAttribute("book", book);
		} catch (Exception e) {
			/*
			 * DB接続エラー
			 */

			//エラーメッセージを設定
			if (cmd.equals("detail")) {
				errorMessage = "DB接続エラーの為、書籍詳細は表示できませんでした。";
			} else if (cmd.equals("update")) {
				errorMessage = "DB接続エラーの為、変更画面は表示できませんでした。 ";
			}

			//errorCmdに値を登録
			errorCmd = "logout";

		} finally {
			if (errorCmd == null) {
				//エラーがない場合の処理
				if (cmd.equals("detail")) {

					//cmdの値が「detail」ならば、detail.jspへフォワードする
					request.getRequestDispatcher("/view/detail.jsp").forward(request, response);

				} else if (cmd.equals("update")) {

					//cmdの値が「update」ならば、update.jspへフォワードする
					request.getRequestDispatcher("/view/update.jsp").forward(request, response);

				}
			} else {
				//リクエストスコープにエラーメッセージを登録する
				request.setAttribute("error_message", errorMessage);

				//リクエストスコープにcmdを登録する
				request.setAttribute("cmd", errorCmd);

				//error.jspへフォワードする
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}

	}
}
