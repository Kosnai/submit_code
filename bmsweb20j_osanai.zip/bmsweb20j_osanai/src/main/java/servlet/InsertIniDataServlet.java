package servlet;

/*
 * プログラム名：InsertIniDataServlet
 * プログラムの説明：書籍情報が一件も無い場合に、csvファイルからデータを取得し、データベースに登録するプログラム。
 * 作成者：小山内滉貴
 * 作成日：2024/05/21
 */

import java.io.IOException;
import java.util.ArrayList;

import bean.Book;
import dao.BookDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import util.FileIn;

@WebServlet("/InsertIniDataServlet")
public class InsertIniDataServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//エラーメッセージとcmdを格納する変数
		String errorMessage = null;
		String errorCmd = null;

		try {
			//BookDAOクラスのオブジェクトを生成
			BookDAO bookDao = new BookDAO();

			//検索した書籍情報を登録するArrayListオブジェクトを生成し、データを取得
			ArrayList<Book> list = bookDao.selectAll();

			//書籍データがあるか判別(書籍データがある場合はエラー処理)
			if (list.size() != 0) {
				//エラーメッセージを設定
				errorMessage = "DBにはデータが存在するので、初期データは登録できません。 ";

				//errorCmdに値を登録
				errorCmd = "menu";

				return;
			}

			//csvファイルのパスを取得
			String path = getServletContext().getRealPath("file\\initial_data.csv");

			FileIn fileIn = new FileIn();

			//csvファイルを開けるかどうかの条件処理
			if (fileIn.open(path)) {
				while (true) {
					//csvファイルの1行分のデータを取得
					String buff = fileIn.readLine();

					if (buff == null) {
						break;
					} else {
						//「,」で分ける
						String[] fileData = buff.split(",");

						if (fileData.length == 3) {
							//Bookオブジェクト作成
							Book book = new Book();

							//isbn,title,priceに値を代入
							book.setIsbn(fileData[0]);
							book.setTitle(fileData[1]);
							book.setPrice(Integer.parseInt(fileData[2]));

							//listに追加
							list.add(book);
						} else {
							//エラーメッセージを設定
							errorMessage = "初期データファイルが不備がある為、登録は行えません。 ";

							//errorCmdに値を登録
							errorCmd = "menu";

							return;
						}
					}

				}

				//ファイルがクローズできるかどうかの条件処理
				if (fileIn.close()) {
					//リクエストスコープにデータを登録
					request.setAttribute("book_list", list);

					//データベースに登録
					for (int i = 0; i < list.size(); i++) {
						bookDao.insert(list.get(i));
					}
				} else {
					//エラーメッセージを設定
					errorMessage = "初期データファイルが無い為、登録は行えません。";

					//errorCmdに値を登録
					errorCmd = "menu";

					return;
				}

			} else {
				//エラーメッセージを設定
				errorMessage = "初期データファイルが無い為、登録は行えません。";

				//errorCmdに値を登録
				errorCmd = "menu";
			}

		} catch (

		NumberFormatException e) {
			/*
			 * price関連のエラー(初期値)
			 */

			//エラーメッセージを設定
			errorMessage = "初期データファイルが不備がある為、登録は行えません。 ";

			//errorCmdに値を登録
			errorCmd = "menu";

		} catch (Exception e) {
			/*
			 * DB接続エラー
			 */

			//エラーメッセージを設定
			errorMessage = "DB接続エラーの為、初期データ登録は行えません。 ";

			//errorCmdに値を登録
			errorCmd = "logout";

		} finally {
			if (errorCmd == null) {
				//insertIniData.jspへフォワードする
				request.getRequestDispatcher("/view/insertIniData.jsp").forward(request, response);
			} else {
				//リクエストスコープにエラーメッセージを登録する
				request.setAttribute("error_message", errorMessage);

				//リクエストスコープにcmdを登録する
				request.setAttribute("cmd", errorCmd);

				//error.jspへフォワードする
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}

	}
}
