package servlet;

/*
 * プログラム名：ShowCartServlet
 * プログラムの説明：ユーザーが購入予定の書籍を一覧表示するプログラム。
 * 作成者：小山内滉貴
 * 作成日：2024/05/21
 */

import java.io.IOException;
import java.util.ArrayList;

import bean.Book;
import bean.Order;
import bean.User;
import dao.BookDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@SuppressWarnings("unchecked")
@WebServlet("/ShowCartServlet")
public class ShowCartServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//エラーメッセージとcmdを格納する変数
		String errorMessage = null;
		String errorCmd = null;

		try {

			//(カート内から)削除対象の配列要素番号を取得
			String delno = request.getParameter("delno");

			//セッションオブジェクト作成
			HttpSession session = request.getSession();

			//セッションから"user"のUserオブジェクトを取得
			User user = (User) session.getAttribute("user");

			//セッション切れの場合の処理
			if (user == null) {
				//エラーメッセージを設定
				errorMessage = "セッション切れの為、カート状況は確認出来ません。";

				//errorCmdに値を登録
				errorCmd = "logout";

				return;
			}

			//セッションから"order_list"を取得
			ArrayList<Order> order_list = (ArrayList<Order>) session.getAttribute("order_list");

			//delnoがnullでない場合の処理
			if (delno != null) {
				//delnoで指定されたorder_listの要素を削除する
				order_list.remove(Integer.parseInt(delno));
			}

			//BookDAOクラスのオブジェクトを生成
			BookDAO bookDao = new BookDAO();

			//カートに入れてある書籍の情報を格納する配列
			ArrayList<Book> list = new ArrayList<Book>();

			if (order_list != null) {
				for (int i = 0; i < order_list.size(); i++) {

					//selectByIsbnメソッドを呼び出す
					Book book = bookDao.selectByIsbn(order_list.get(i).getIsbn());

					if (book.getIsbn() != null) {
						//listに書籍情報を追加
						list.add(book);
					} else {
						order_list.remove(i);
					}
				}
			}

			//リクエストスコープに"book_list"という名前で登録
			request.setAttribute("book_list", list);
		} catch (Exception e) {
			/*
			 * DB接続エラー
			 */

			//エラーメッセージを設定
			errorMessage = "DB接続エラーの為、カート状況は確認出来ません。";

			//errorCmdに値を登録
			errorCmd = "logout";
		} finally {
			if (errorCmd == null) {
				//showCart.jspにフォワードする
				request.getRequestDispatcher("/view/showCart.jsp").forward(request, response);
			} else {
				//リクエストスコープにエラーメッセージを登録する
				request.setAttribute("error_message", errorMessage);

				//リクエストスコープにcmdを登録する
				request.setAttribute("cmd", errorCmd);

				//error.jspへフォワードする
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}

	}
}
