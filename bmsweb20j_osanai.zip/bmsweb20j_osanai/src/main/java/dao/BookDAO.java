package dao;

/*
 * プログラム名：BookDAO
 * プログラムの説明：書籍情報に関するデータベースへアクセスする処理がまとめられている。
 *                   書籍情報に関する処理を行う場合に使用される。
 * 作成者：小山内滉貴
 * 作成日：2024/05/21
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.Book;

public class BookDAO {
	//データベース接続情報
	private static String RDB_DRIVE = "org.mariadb.jdbc.Driver";
	private static String URL = "jdbc:mariadb://localhost/mybookdb";
	private static String USER = "root";
	private static String PASS = "root123";

	//データベースに接続するクラスメソッド
	private static Connection getConnection() {
		try {
			Class.forName(RDB_DRIVE);
			Connection co = DriverManager.getConnection(URL, USER, PASS);
			return co;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	//データベースから書籍データを検索しArrayListオブジェクトに格納する
	public ArrayList<Book> selectAll() {
		//変数宣言
		Connection con = null;//DBコネクション
		Statement smt = null;//SQLステートメント

		//SQL文作成(表示)
		String display = "SELECT isbn,title,price FROM bookinfo ORDER BY isbn";

		ArrayList<Book> bookList = new ArrayList<Book>();

		try {
			//データベースに接続
			con = BookDAO.getConnection();
			smt = con.createStatement();

			//SQL文発行
			ResultSet rs = smt.executeQuery(display);

			//検索結果をArrayListに保存
			while (rs.next()) {
				Book book = new Book();
				book.setIsbn(rs.getString("isbn"));
				book.setTitle(rs.getString("title"));
				book.setPrice(rs.getInt("price"));
				bookList.add(book);
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			//Statementオブジェクトのクローズ
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
					//例外処理の無視
				}
			}
			//Connectionオブジェクトのクローズ
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
					//例外処理の無視
				}
			}
		}

		return bookList;

	}

	//データベースに書籍データを登録するインスタンスメソッド
	public void insert(Book book) {
		//変数宣言
		Connection con = null;//DBコネクション
		Statement smt = null;//SQLステートメント

		//SQL文作成(登録)
		String add = "INSERT INTO bookinfo VALUES('" + book.getIsbn() + "','" + book.getTitle() + "',"
				+ book.getPrice() + ")";

		try {
			//データベースに接続
			con = BookDAO.getConnection();
			smt = con.createStatement();

			//SQL文発行
			smt.executeUpdate(add);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			//Statementオブジェクトのクローズ
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
					//例外処理の無視
				}
			}
			//Connectionオブジェクトのクローズ
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
					//例外処理の無視
				}
			}
		}
	}

	//データベースから指定されたIdbn値の書籍データを検索するインスタンスメソッド
	public Book selectByIsbn(String isbn) {
		//変数宣言
		Connection con = null;//DBコネクション
		Statement smt = null;//SQLステートメント

		//SQL文作成(検索)
		String searchIsbn = "SELECT isbn,title,price FROM bookinfo WHERE isbn = '" + isbn + "'";

		//検索した書籍情報を格納するオブジェクトの生成
		Book book = new Book();

		try {
			//データベースに接続
			con = BookDAO.getConnection();
			smt = con.createStatement();

			//SQL文発行
			ResultSet rs = smt.executeQuery(searchIsbn);

			//取得したデータをbookオブジェクトに格納
			if (rs.next()) {
				book.setIsbn(rs.getString("isbn"));
				book.setTitle(rs.getString("title"));
				book.setPrice(rs.getInt("price"));
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			//Statementオブジェクトのクローズ
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
					//例外処理の無視
				}
			}
			//Connectionオブジェクトのクローズ
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
					//例外処理の無視
				}
			}
		}

		return book;
	}

	//データベースから指定された書籍データを消去するインスタンスメソッド
	public void delete(String isbn) {
		//変数宣言
		Connection con = null;//DBコネクション
		Statement smt = null;//SQLステートメント

		//SQL文作成(削除)
		String delete = "DELETE FROM bookinfo WHERE isbn = '" + isbn + "'";

		try {
			//データベースに接続
			con = BookDAO.getConnection();
			smt = con.createStatement();

			//SQL文発行
			smt.executeUpdate(delete);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			//Statementオブジェクトのクローズ
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
					//例外処理の無視
				}
			}
			//Connectionオブジェクトのクローズ
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
					//例外処理の無視
				}
			}
		}
	}

	//データベースから指定された書籍データを更新するインスタンスメソッド
	public void update(Book book) {
		//変数宣言
		Connection con = null;//DBコネクション
		Statement smt = null;//SQLステートメント

		//SQL文作成(更新)
		String upD = "UPDATE bookinfo SET title='" + book.getTitle() + "',price=" + book.getPrice() + " WHERE isbn='"
				+ book.getIsbn() + "'";

		try {
			//データベースに接続
			con = BookDAO.getConnection();
			smt = con.createStatement();

			//SQL文発行
			smt.executeUpdate(upD);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			//Statementオブジェクトのクローズ
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
					//例外処理の無視
				}
			}
			//Connectionオブジェクトのクローズ
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
					//例外処理の無視
				}
			}
		}

	}

	//データベースから指定された書籍データを検索するインスタンスメソッド
	public ArrayList<Book> search(String isbn, String title, String price) {
		//変数宣言
		Connection con = null;//DBコネクション
		Statement smt = null;//SQLステートメント

		//検索した書籍情報を格納するArrayListオブジェクト
		ArrayList<Book> bookList = new ArrayList<Book>();

		//SQL文作成(検索)
		String search = "SELECT isbn,title,price FROM bookinfo " +
				"WHERE isbn LIKE '%" + isbn + "%' AND title LIKE '%" + title + "%' AND price LIKE '%" + price + "%'";

		try {
			//データベースに接続
			con = BookDAO.getConnection();
			smt = con.createStatement();

			//SQL文発行
			ResultSet rs = smt.executeQuery(search);

			//検索結果をArrayListに保存
			while (rs.next()) {
				Book book = new Book();
				book.setIsbn(rs.getString("isbn"));
				book.setTitle(rs.getString("title"));
				book.setPrice(rs.getInt("price"));
				bookList.add(book);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			//Statementオブジェクトのクローズ
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
					//例外処理の無視
				}
			}
			//Connectionオブジェクトのクローズ
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
					//例外処理の無視
				}
			}
		}

		return bookList;
	}
}