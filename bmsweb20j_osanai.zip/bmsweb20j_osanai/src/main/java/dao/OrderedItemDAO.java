package dao;

/*
 * プログラム名：OrderedItemDAO
 * プログラムの説明：注文情報と書籍情報に関するデータベースへアクセスし、
 *                   必要情報(書籍を購入したユーザーのID、購入した書籍タイトル、購入日)を戻り値として返す。              
 * 作成者：小山内滉貴
 * 作成日：2024/05/21
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.OrderedItem;


public class OrderedItemDAO {
	//データベース接続情報
	private static String RDB_DRIVE = "org.mariadb.jdbc.Driver";
	private static String URL = "jdbc:mariadb://localhost/mybookdb";
	private static String USER = "root";
	private static String PASS = "root123";

	//データベースに接続するクラスメソッド
	private static Connection getConnection() {
		try {
			Class.forName(RDB_DRIVE);
			Connection co = DriverManager.getConnection(URL, USER, PASS);
			return co;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	/*
	 * DBのuserinfoテーブルから指定ユーザーとパスワードの条件に合致する情報を取得するメソッド
	 */
	public ArrayList<OrderedItem> selectAll() {
		//変数宣言
		Connection con = null;//DBコネクション
		Statement smt = null;//SQLステートメント

		//SQL文作成
		String sql = "SELECT o.user,b.title,o.date FROM bookinfo b INNER JOIN orderinfo o ON b.isbn=o.isbn";

		ArrayList<OrderedItem> orderItemList = new ArrayList<OrderedItem>();

		try {
			//データベースに接続
			con = OrderedItemDAO.getConnection();
			smt = con.createStatement();

			//SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			//検索結果をArrayListに保存
			while (rs.next()) {
				OrderedItem orderedItem=new OrderedItem();
				orderedItem.setUserid(rs.getString("user"));
				orderedItem.setTitle(rs.getString("title"));
				orderedItem.setDate(rs.getString("date"));
				orderItemList.add(orderedItem);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			//Statementオブジェクトのクローズ
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
					//例外処理の無視
				}
			}
			//Connectionオブジェクトのクローズ
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
					//例外処理の無視
				}
			}
		}

		return orderItemList;
	}

}

