package dao;

/*
 * プログラム名：UserDAO
 * プログラムの説明：ユーザー情報に関するデータベースへアクセスする処理がまとめられている。
 *                   ユーザー情報に関する処理を行う場合に使用される。
 * 作成者：小山内滉貴
 * 作成日：2024/05/21
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import bean.User;

public class UserDAO {
	//データベース接続情報
	private static String RDB_DRIVE = "org.mariadb.jdbc.Driver";
	private static String URL = "jdbc:mariadb://localhost/mybookdb";
	private static String USER = "root";
	private static String PASS = "root123";

	//データベースに接続するクラスメソッド
	private static Connection getConnection() {
		try {
			Class.forName(RDB_DRIVE);
			Connection co = DriverManager.getConnection(URL, USER, PASS);
			return co;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	/*
	 * DBのuserinfoテーブルから指定ユーザーとパスワードの条件に合致する情報を取得するメソッド
	 */
	public User selectByUser(String userid, String password) {
		//変数宣言
		Connection con = null;//DBコネクション
		Statement smt = null;//SQLステートメント

		//SQL文作成(検索)
		String sql = "SELECT * FROM userinfo WHERE user ='" + userid + "' AND password='" + password + "'";

		//検索したユーザーidとパスワードを格納するオブジェクトの生成
		User user = new User();

		try {
			//データベースに接続
			con = UserDAO.getConnection();
			smt = con.createStatement();

			//SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			//取得したデータをbookオブジェクトに格納
			if (rs.next()) {
				user.setUserid(rs.getString("user"));
				user.setPassword(rs.getString("password"));
				user.setAuthority(rs.getString("authority"));
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			//Statementオブジェクトのクローズ
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
					//例外処理の無視
				}
			}
			//Connectionオブジェクトのクローズ
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
					//例外処理の無視
				}
			}
		}

		return user;
	}

}
