package bean;

/*
 * プログラム名：User
 * プログラムの説明：ユーザー情報を取り扱う。
 *                   アクセサメソッドにアクセスすることでユーザー情報の取得、及び変更が可能。   
 * 作成者：小山内滉貴
 * 作成日：2024/05/21
 */

public class User {
	//ユーザー名を格納する変数
	private String userid;

	//パスワードを格納する変数
	private String password;

	//メールアドレスを格納する変数
	private String email;

	//権限を格納する変数
	private String authority;

	//コンストラクタで各変数を初期化
	public User() {
		this.userid = null;
		this.password = null;
		this.email = null;
		this.authority = null;
	}

	/*
	 * useridのアクセサメソッドを定義
	 */
	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	/*
	 * passwordのアクセサメソッドを定義
	 */
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	/*
	 * authorityのアクセサメソッドを定義
	 */
	public String getAuthority() {
		return authority;
	}

	public void setAuthority(String authority) {
		this.authority = authority;
	}

	/*
	 * emailのアクセサメソッドを定義
	 */
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
