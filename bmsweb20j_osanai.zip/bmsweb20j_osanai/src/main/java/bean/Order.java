package bean;

/*
 * プログラム名：Order
 * プログラムの説明：注文情報を取り扱う。
 *                   アクセサメソッドにアクセスすることで注文情報の取得、及び変更が可能。  
 * 作成者：小山内滉貴
 * 作成日：2024/05/21
 */

public class Order {
	//注文Noを格納する変数
	private int orderno;

	//ユーザーIDを格納する変数
	private String userid;

	//ISBNを格納する変数
	private String isbn;

	//数量を格納する変数
	private int quantity;

	//購入日付を格納する変数
	private String date;

	//コンストラクタで各変数を初期化
	public Order() {
		this.orderno = 0;
		this.userid = null;
		this.isbn = null;
		this.quantity = 0;
		this.date = null;
	}
	
	/*
	 * ordernoのアクセサメソッドを定義
	 */
	public int getOrderno() {
		return orderno;
	}

	public void setOrderno(int orderno) {
		this.orderno = orderno;
	}
	
	/*
	 * useridのアクセサメソッドを定義
	 */
	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}
	
	/*
	 * isbnのアクセサメソッドを定義
	 */
	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	
	/*
	 * quantityのアクセサメソッドを定義
	 */
	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	/*
	 * dateのアクセサメソッドを定義
	 */
	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}
}
