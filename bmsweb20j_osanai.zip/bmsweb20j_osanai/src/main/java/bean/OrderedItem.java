package bean;

/*
 * プログラム名：OrderedItem
 * プログラムの説明：書籍を購入したユーザーのID、及び購入した書籍タイトルと購入日を取り扱う。
 *                   アクセサメソッドにアクセスすることで上記内容の取得、及び変更が可能。  
 * 作成者：小山内滉貴
 * 作成日：2024/05/21
 */

public class OrderedItem {
	//ユーザーIDを格納する変数
	private String userid;

	//書籍のタイトルを格納する変数
	private String title;

	//購入日付を格納する変数
	private String date;

	//コンストラクタで各変数を初期化
	public OrderedItem() {
		this.userid = null;
		this.title = null;
		this.date = null;
	}

	/*
	 * useridのアクセサメソッドを定義
	 */
	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	/*
	 * titleのアクセサメソッドを定義
	 */
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	/*
	 * dateのアクセサメソッドを定義
	 */
	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}
}
