package bean;

/*
 * プログラム名：Book
 * プログラムの説明：書籍情報を取り扱う。
 *                   アクセサメソッドにアクセスすることで書籍情報の取得、及び変更が可能。  
 * 作成者：小山内滉貴
 * 作成日：2024/05/21
 */

public class Book {
	//書籍番号を格納する変数
	private String isbn;

	//タイトルを格納する変数
	private String title;

	//価格を格納する変数
	private int price;

	//コンストラクタで各変数を初期化
	public Book() {
		this.isbn = null;
		this.title = null;
		this.price = 0;
	}

	/*
	 * isbnのアクセサメソッドを定義
	 */
	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	/*
	 * titleのアクセサメソッドを定義
	 */
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	/*
	 * priceのアクセサメソッドを定義
	 */
	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
}
