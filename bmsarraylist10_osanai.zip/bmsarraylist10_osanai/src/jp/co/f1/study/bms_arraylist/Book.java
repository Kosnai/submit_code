package jp.co.f1.study.bms_arraylist;

/*
 * プログラム名：Book
 * プログラムの説明：書籍のデータを格納するためのクラスです。            
 * 作成者：小山内滉貴
 * 作成日：2024/04/24
 */

public class Book {
	//フィールド変数
	private String isbn;//ISBN

	private String title;//タイトル

	private int price;//価格
	
	//コンストラクタ(引数なし)
	public Book() {
		//初期化
		this.isbn=null;
		this.title=null;
		this.price=0;
	}

	//コンストラクタ(引数あり)
	public Book(String isbn, String title, int price) {
		//初期化
		this.isbn = isbn;
		this.title = title;
		this.price = price;
	}

	/*
	 * getterメソッドの定義
	 */
	public String getIsbn() {
		return this.isbn;
	}

	public String getTitle() {
		return this.title;
	}

	public int getPrice() {
		return this.price;
	}

	/*
	 * setterメソッドの定義
	 */
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setPrice(int price) {
		this.price = price;
	}
}
