package jp.co.f1.study.bms_arraylist;

public class BmsArrayListTester {
	public static void main(String[] args) {
		//BmsFunctionArrayListのオブジェクトを作成
		BmsFunctionArrayList bms = new BmsFunctionArrayList();

		//メニュー番号を保存する変数
		int menuKey;

		while (true) {
			//BmsFunctionArrayList内にあるメソッドの呼び出し
			bms.displayMenu();
			menuKey = bms.selectFunctionFromMenu();

			//メニュー番号が9ならば処理を終了する
			if (menuKey == 9) {
				break;
			} 
		}
	}
}
