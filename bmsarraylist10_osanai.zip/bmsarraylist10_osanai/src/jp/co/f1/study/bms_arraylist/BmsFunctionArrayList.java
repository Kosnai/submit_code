package jp.co.f1.study.bms_arraylist;

import java.util.ArrayList;

import jp.co.f1.study.common.KeyIn;

public class BmsFunctionArrayList {
	//書籍を格納する用のArrayList
	private ArrayList<Book> bookList = new ArrayList<Book>();

	//提供ライブラリのオブジェクト
	private KeyIn objKeyIn = new KeyIn();

	//水平タブを定数で扱う
	private final String TAB = "\t";

	//書籍管理システムのメニューを表示する
	public void displayMenu() {
		System.out.println("  ***書籍管理MENU***");
		System.out.println(" 1.登録");
		System.out.println(" 2.一覧");
		System.out.println(" 9.終了");
		System.out.println("-----------------------");
	}

	//メニュー番号を選択し、該当する機能を呼び出すインスタンスメソッド
	public int selectFunctionFromMenu() {
		//メニュー番号を保存する変数の宣言と入力処理
		int menuKey = objKeyIn.readInt(" 番号を選択してください⇒");

		//分岐条件
		switch (menuKey) {
		case 1:
			//addFunctionの呼び出し
			addFunction();

			break;
		case 2:
			//listFunctionメソッドの呼び出し
			listFunction();

			break;
		case 9:
			System.out.println("\n**処理を終了しました**");
			break;
		default:
			System.out.println("正しいメニュー番号を入力してください。\n");
			break;
		}

		//戻り値としてメニュー番号を返す
		return menuKey;
	}

	//書籍データをArrayListオブジェクトに格納するインスタンスメソッド
	public void writeIntoMemoryInitially() {
		//フィールド変数
		String[] isbn = { "1111", "2222", "3333" };//ISBN
		String[] title = { "java", "perl", "html" };//タイトル
		int[] price = { 1100, 1200, 1300 };//価格

		//初期書籍データをbookListに格納
		for (int i = 0; i < isbn.length; i++) {
			bookList.add(new Book(isbn[i], title[i], price[i]));
		}
		
		//listFunctionメソッド呼び出し
		listFunction();
	}

	//一覧機能を統括するインスタンスメソッド
	public void listFunction() {
		if (bookList.isEmpty()) {
			writeIntoMemoryInitially();
		} else {
			System.out.println("\n  ***書籍一覧***");
			System.out.println("No." + TAB + TAB + "isbn" + TAB + "title" + TAB + "price" + TAB);
			System.out.println("----------------------------------------------");

			//ArrayListに登録されている情報を表示するための繰り返し文
			for (int i = 0; i < bookList.size(); i++) {
				System.out.println(
						(i + 1) + "." + TAB + TAB + bookList.get(i).getIsbn() + TAB + bookList.get(i).getTitle()
								+ TAB + bookList.get(i).getPrice());
			}

			System.out.println("----------------------------------------------\n");
		}
	}

	//登録機能を統括するインスタンスメソッド
	public void addFunction() {
		Book book = new Book();

		System.out.println("\n***書籍情報登録***");

		//ISBN入力処理
		System.out.println("ISBNを入力してください。");
		book.setIsbn(objKeyIn.readKey("【ISBN】⇒"));

		//タイトル入力処理
		System.out.println("タイトルを入力してください。");
		book.setTitle(objKeyIn.readKey("【タイトル】⇒"));

		//価格入力処理
		System.out.println("価格を入力してください。");
		book.setPrice(objKeyIn.readInt("【価格】⇒"));

		//BookオブジェクトをArrayListに追加
		bookList.add(book);

		//追加した書籍データの表示
		System.out.println("\n***登録済書籍情報***");
		System.out.println("isbn" + TAB + "title" + TAB + "price" + TAB);
		System.out.println("----------------------------------------------");
		System.out.println(
				bookList.get(bookList.size() - 1).getIsbn() + TAB + bookList.get(bookList.size() - 1).getTitle()
						+ TAB + bookList.get(bookList.size() - 1).getPrice());
		System.out.println("----------------------------------------------\n");
		System.out.println("上記書籍が登録されました。\n");
	}
}
