package jp.co.f1.study.bms_db;

/*
 * プログラム名：BmsDBTester
 * プログラムの説明：プログラムを開始したら、最初に実行されるmainメソッドがあります。
 *                   9が入力された場合、処理が終了します。            
 * 作成者：小山内滉貴
 * 作成日：2024/04/25
 */

public class BmsDBTester {
	public static void main(String[] args) {
		try {
			//BmsFunctionArrayListのオブジェクトを作成
			BmsFunctionDB bms = new BmsFunctionDB();

			//メニュー番号を保存する変数
			int menuKey;

			while (true) {
				//BmsFunctionDB内にあるメソッドの呼び出し
				bms.displayMenu();
				menuKey = bms.selectFunctionFromMenu();

				//メニュー番号が9ならば処理を終了する
				if (menuKey == 9) {
					break;
				}
			}
		} catch (Exception e) {
			System.out.println(e + "という例外が発生しました。");
		}
	}
}
