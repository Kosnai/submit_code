package jp.co.f1.study.bms_db;

/*
 * プログラム名：BookDAO
 * プログラムの説明：データベースにアクセスするクラスです。 
 *                   主に、データベースからデータを取得する処理や、データを登録する処理を行っています。                
 * 作成者：小山内滉貴
 * 作成日：2024/04/25
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class BookDAO {
	//データベース接続情報
	private static String RDB_DRIVE = "org.mariadb.jdbc.Driver";
	private static String URL = "jdbc:mariadb://localhost/mybookdb";
	private static String USER = "root";
	private static String PASS = "root123";

	//SQL文作成(表示)
	String display = "select * from bookinfo order by isbn";

	//データベースに接続するクラスメソッド
	private static Connection getConnection() {
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASS);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	//データベースから書籍データを検索しArrayListオブジェクトに格納する
	public ArrayList<Book> selectAll() {
		//変数宣言
		Connection con = null;//DBコネクション
		Statement smt = null;//SQLステートメント

		ArrayList<Book> bookList = new ArrayList<Book>();

		try {
			//データベースに接続
			con = BookDAO.getConnection();
			smt = con.createStatement();

			//SQL文発行
			ResultSet rs = smt.executeQuery(display);

			//検索結果をArrayListに保存
			while (rs.next()) {
				Book book = new Book();
				book.setIsbn(rs.getString("isbn"));
				book.setTitle(rs.getString("title"));
				book.setPrice(rs.getInt("price"));
				bookList.add(book);
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			//Statementオブジェクトのクローズ
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
					//例外処理の無視
				}
			}
			//Connectionオブジェクトのクローズ
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
					//例外処理の無視
				}
			}
		}

		return bookList;

	}

	//データベースに書籍データを登録するインスタンスメソッド
	public void insert(Book book) {
		//変数宣言
		Connection con = null;//DBコネクション
		Statement smt = null;//SQLステートメント

		//SQL文作成(登録)
		String add = "INSERT INTO bookinfo VALUES('" + book.getIsbn() + "','" + book.getTitle() + "',"
				+ book.getPrice() + ")";

		try {
			//データベースに接続
			con = BookDAO.getConnection();
			smt = con.createStatement();

			//SQL文発行
			smt.executeUpdate(add);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			//Statementオブジェクトのクローズ
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
					//例外処理の無視
				}
			}
			//Connectionオブジェクトのクローズ
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
					//例外処理の無視
				}
			}
		}
	}

	//指定されたIsbn情報を元にデータベースから書籍データを検索するインスタンスメソッド
	public Book selectByIsbn(String isbn) {
		//変数宣言
		Connection con = null;//DBコネクション
		Statement smt = null;//SQLステートメント

		//SQL文作成(検索)
		String search = "SELECT isbn,title,price FROM bookinfo WHERE isbn = '" + isbn + "'";

		Book book = new Book();

		try {
			//データベースに接続
			con = BookDAO.getConnection();
			smt = con.createStatement();

			//SQL文発行
			ResultSet rs = smt.executeQuery(search);

			//同じIsbn値があったら終了
			while (rs.next()) {
				book.setIsbn(rs.getString("isbn"));

				if (book.getIsbn().equals(isbn)) {
					break;
				}
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			//Statementオブジェクトのクローズ
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
					//例外処理の無視
				}
			}
			//Connectionオブジェクトのクローズ
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
					//例外処理の無視
				}
			}
		}

		return book;
	}
}
