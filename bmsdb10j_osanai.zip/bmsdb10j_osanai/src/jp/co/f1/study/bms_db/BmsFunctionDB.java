package jp.co.f1.study.bms_db;

/*
 * プログラム名：BmsFunctionDB
 * プログラムの説明：選択されたメニュー番号によって処理がそれぞれ行われます。
 *                   メニュー番号1の場合は、データベースに書籍情報を登録します。
 *                   もし、空文字や既存のIsbn値が入力された場合、メッセージを出力し、再度入力してもらいます。
 *                   メニュー番号3の場合は、データベースの情報を表示します。            
 * 作成者：小山内滉貴
 * 作成日：2024/04/25
 */

import java.util.ArrayList;

import jp.co.f1.study.common.KeyIn;

public class BmsFunctionDB {
	//提供ライブラリのオブジェクト
	private KeyIn objKeyIn = new KeyIn();

	//書籍データを格納するためArrayListオブジェクト
	ArrayList<Book> bookList = new ArrayList<Book>();

	//DAOのオブジェクト
	BookDAO objDao = new BookDAO();

	//水平タブを定数で扱う
	private final String TAB = "\t";

	//書籍管理システムのメニューを表示する
	public void displayMenu() {
		System.out.println("  ***書籍管理MENU***");
		System.out.println(" 1.登録");
		System.out.println(" 2.削除(Ver.2.0で実装)");
		System.out.println(" 3.変更(Ver.2.0で実装)");
		System.out.println(" 4.一覧");
		System.out.println(" 9.終了");
		System.out.println("-----------------------");
	}

	//メニュー番号を選択し、該当する機能を呼び出すインスタンスメソッド
	public int selectFunctionFromMenu() {
		//メニュー番号を保存する変数の宣言と入力処理
		int menuKey = objKeyIn.readInt(" 番号を選択してください⇒");

		//分岐条件
		switch (menuKey) {
		case 1:
			addFunction();
			break;
		case 2:
			System.out.println("selectFunctionFromMenuメソッドの中で「2. 削除」が選択されました。\n");
			break;
		case 3:
			System.out.println("selectFunctionFromMenuメソッドの中で「3. 変更」が選択されました。\n");
			break;
		case 4:
			listFunction();
			break;
		case 9:
			System.out.println("\n**処理を終了しました**");
			break;
		default:
			System.out.println("Menu番号の数値を入力してください。\n");
			break;
		}

		//戻り値としてメニュー番号を返す
		return menuKey;
	}

	//フィールド変数bookList内のデータをコンソールに表示するインスタンスメソッド
	public void bookListDisplay() {

		System.out.println("\n  ***書籍一覧***");
		System.out.println("No." + TAB + TAB + "isbn" + TAB + "title" + TAB + "price" + TAB);
		System.out.println("----------------------------------------------");

		//bookyListに登録されている情報を表示するための繰り返し文
		for (int i = 0; i < bookList.size(); i++) {
			System.out.println(
					(i + 1) + "." + TAB + TAB + bookList.get(i).getIsbn() + TAB + bookList.get(i).getTitle()
							+ TAB + bookList.get(i).getPrice());
		}

		System.out.println("----------------------------------------------\n");

	}

	//一覧機能を統括するインスタンスメソッド
	public void listFunction() {
		//全ての書籍データを取得
		bookList = objDao.selectAll();

		//表示メソッド
		bookListDisplay();
	}

	//登録機能を統括するインスタンスメソッド
	public void addFunction() {
		Book book = new Book();

		System.out.println("\n***書籍情報登録***");

		//ISBN入力処理
		System.out.println("ISBNを入力してください。");
		
		while (true) {
			book.setIsbn(objKeyIn.readKey("【ISBN】⇒"));

			//空文字が入力された場合の処理
			if (book.getIsbn().equals("")) {
				System.out.println("空文字が入力されました。ISBNを入力して下さい！");
				continue;
			}

			//入力されたIsbnがあった場合の処理
			if (!(objDao.selectByIsbn(book.getIsbn()).getIsbn() == null)) {
				System.out.println("入力ISBNは既に登録されています：" + book.getIsbn());
				continue;
			}

			break;
		}

		//タイトル入力処理
		System.out.println("タイトルを入力してください。");
		book.setTitle(objKeyIn.readKey("【タイトル】⇒"));

		//価格入力処理
		System.out.println("価格を入力してください。");
		book.setPrice(objKeyIn.readInt("【価格】⇒"));

		//入力内容をbookListに保存
		bookList.add(book);

		//Bookオブジェクトをinsert()メソッドを用いて、データベースに追加
		objDao.insert(book);

		//全ての書籍データを取得
		bookList = objDao.selectAll();

		//追加した書籍データの表示
		System.out.println("\n***登録済書籍情報***");
		System.out.println("isbn" + TAB + "title" + TAB + "price" + TAB);
		System.out.println("----------------------------------------------");
		System.out.println(
				bookList.get(bookList.size() - 1).getIsbn() + TAB + bookList.get(bookList.size() - 1).getTitle()
						+ TAB + bookList.get(bookList.size() - 1).getPrice());
		System.out.println("----------------------------------------------\n");
		System.out.println("上記書籍が登録されました。\n");
	}
}
