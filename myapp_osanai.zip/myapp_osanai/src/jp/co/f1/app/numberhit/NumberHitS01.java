/*
 * プログラム名：数字当てプログラムStep1
 * プログラムの説明：ユーザーに予想数字として0～9の値を入力してもらい、
 *                   予想数字と正解数字を表示する。
 * 作成者：小山内滉貴
 * 作成日：2024/04/15
 */

package jp.co.f1.app.numberhit;

import java.util.Scanner;

public class NumberHitS01 {
	public static void main(String[] args) {
		//キーボード入力準備
		Scanner scan = new Scanner(System.in);
		
		//正解数字
		int answerNum = 5;
		//ゲーム開始時のメッセージ
		System.out.println("ゲーム開始");
		System.out.println();
		
		//キーボードから予想数字を入力
		System.out.print(" 0から9までの予想の数字を入力>>");
		int playerNum = scan.nextInt();
		
		//予想数字の表示
		System.out.println("   →予想数字は"+playerNum+"です。");
		
		//正解数字の表示
		System.out.println("   →正解数字は"+answerNum+"です。");
		System.out.println();
		
		//ゲーム終了時のメッセージ
		System.out.println("ゲーム終了");
		
		//Scannerのclose
		scan.close();
	}
}
