/*
 * プログラム名：数字当てプログラムStep2
 * プログラムの説明：ユーザーに予想数字として0～9の値を入力してもらい、
 *                   正解数字が予想数字より大きい場合は正解数字より大きいと表示し、
 *                   正解数字が予想数字より小さい場合は正解数字より小さいと表示する。
 *                   また、正解数字と予想数字が同じだった場合は大当たりと表示する。
 * 作成者：小山内滉貴
 * 作成日：2024/04/15
 */

package jp.co.f1.app.numberhit;

import java.util.Scanner;

public class NumberHitS02 {
	public static void main(String[] args) {
		//キーボード入力準備
		Scanner scan = new Scanner(System.in);
		
		//正解数字
		int answerNum = 5;
		//ゲーム開始時のメッセージ
		System.out.println("ゲーム開始(正解数字 : "+answerNum+")");
		System.out.println();
		
		//キーボードから予想数字を入力
		System.out.print(" 0から9までの予想の数字を入力>>");
		int playerNum = scan.nextInt();
		
		//正解数字が予想数字より大きいか小さいか同じか判定する処理
		if(answerNum>playerNum) {
			
			//正解数字が予想数字より大きい場合の処理
			System.out.println("	→正解数字は"+playerNum+"より大きいです。");
			
		} else if(answerNum<playerNum) {
			
			//正解数字が予想数字より小さい場合の処理
			System.out.println("	→正解数字は"+playerNum+"より小さいです。");
			
		} else {
			
			//正解数字と予想数字が同じだった場合の処理
			System.out.println("	→! ! 大当たり ! !");
			
		}
		
		
		//ゲーム終了時のメッセージ
		System.out.println("\nゲーム終了");
		
		//Scannerのclose
		scan.close();
	}
}
