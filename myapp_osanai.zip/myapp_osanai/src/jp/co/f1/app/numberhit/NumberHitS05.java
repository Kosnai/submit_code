/*
 * プログラム名：数字当てプログラムStep5
 * プログラムの説明：ユーザーに予想数字として0～9の値を入力してもらい、
 *                   正解数字と予想数字が同じになるまで繰り返し処理を行う。
 *                   またユーザーが999と入力した場合は、その時点で繰り返し処理を終了する。
 *                   0～9以外の数値が入力された場合は、エラー表示を行い、再度数値を入力してもらう。
 *                   
 * 作成者：小山内滉貴
 * 作成日：2024/04/15
 */

package jp.co.f1.app.numberhit;

import java.util.Scanner;

public class NumberHitS05 {
	public static void main(String[] args) {
		//キーボード入力準備
		Scanner scan = new Scanner(System.in);
		
		//正解数字
		int answerNum = 5;
		
		//ゲーム開始時のメッセージ
		System.out.println("ゲーム開始(正解数字 : "+answerNum+")");
		System.out.println();
		
		//whileループ処理
		while(true) {

			//キーボードから予想数字を入力
			System.out.print(" 0から9までの予想の数字を入力>>");
			int playerNum = scan.nextInt();
			
			//キーボードから999と入力された場合の処理
			if(playerNum==999) {
				
				System.out.println("	→"+playerNum+"が入力されたためゲームを終了します。\n");
				
				//whileループ処理を終了させる
				break;
				
			}
			
			//0～9以外の数値が入力された場合の処理
			if(playerNum < 0 || playerNum > 9) {
				
				System.out.println("	→エラー!! 0から9の数字ではありません。\n");
				
				//whileループ処理をスキップし、whileループの先頭へ戻る
				continue;
				
			}

			//正解数字が予想数字より大きいか小さいか同じか判定する処理
			if(answerNum>playerNum) {

				//正解数字が予想数字より大きい場合の処理
				System.out.println("	→正解数字は"+playerNum+"より大きいです。\n");

			} else if(answerNum<playerNum) {

				//正解数字が予想数字より小さい場合の処理
				System.out.println("	→正解数字は"+playerNum+"より小さいです。\n");

			} else {

				//正解数字と予想数字が同じだった場合の処理
				System.out.println("	→! ! 大当たり ! !^\n");
				
				//whileループ処理を終了させる
				break;

			}
			
		}
		
		
		//ゲーム終了時のメッセージ
		System.out.println("ゲーム終了");
		
		//Scannerのclose
		scan.close();
	}
}
