/*
 * プログラム名 : 野球ゲームプログラムStep1
 * プログラムの説明 ： 開始メッセージを表示し、3桁のランダム数字を生成した後、
 *                     終了メッセージを表示する。
 * 作成者 : 小山内滉貴
 * 作成日 : 2024年4月17日
 */
package jp.co.f1.app.baseball;

public class BaseBallS01 {

	public static void main(String[] args) {

		//開始メッセージを表示
		System.out.println("---野球ゲームプログラム開始---\n");

		//ランダムな3つの数値を格納する配列の宣言
		int[] answer = new int[3];

		//ランダムな数字を配列に格納しつつ表示
		System.out.print("3桁のランダム数字(正解数字)は");
		for (int i = 0; i < answer.length; i++) {
			answer[i] = (int) (Math.random() * 10);
			System.out.print(answer[i]);
		}
		System.out.println("です。\n");

		//終了メッセージを表示
		System.out.println("---野球ゲームプログラム終了---\n");

	}

}
