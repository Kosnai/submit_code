/*
 * プログラム名 : 野球ゲームプログラムStep4
 * プログラムの説明 ： プレイヤーがキーボードから3桁の数字(予想数字)を入力し、コンソールに表示する。
 *                     また、入力された数値に対して重複しているかを確認、重複している場合は再度入力を促し、
 *                     ユニークになるまで繰り返す。
 * 作成者 : 小山内滉貴
 * 作成日 : 2024年4月17日
 */
package jp.co.f1.app.baseball;

import java.util.Scanner;

public class BaseBallS04 {

	public static void main(String[] args) {

		//開始メッセージを表示
		System.out.println("---野球ゲームプログラム開始---\n");

		//ランダムな3つの数値を格納する配列の宣言
		int[] answer = new int[3];
		String[] playerNum = new String[3];

		//キーボード入力準備
		Scanner sc = new Scanner(System.in);
		int inputNum;//入力された数値を格納する変数

		//無限ループ(自動生成)
		while (true) {
			//ランダムな数字を配列に格納しつつ表示
			System.out.print("3桁のランダム数字(正解数字)は");
			for (int i = 0; i < answer.length; i++) {
				answer[i] = (int) (Math.random() * 10);
				System.out.print(answer[i]);
			}
			System.out.println("です。");

			//ユニークか重複しているか確認
			if (uniqueCheck(answer)) {
				System.out.println("⇒ユニークです。\n");
				break;
			} else {
				System.out.println("⇒重複しています。\n");
			}

		}

		//無限ループ(ユーザー入力)
		while (true) {

			//キーボード入力
			System.out.print("3桁の数字を入力してください＞＞");
			inputNum = sc.nextInt();

			//3桁の数字を各桁に分解し、playerNumに代入。
			for (int i = 0; i < playerNum.length; i++) {
				playerNum[i] = Integer.toString(inputNum).substring(i, i + 1);
			}

			//ユニークか重複しているか確認
			if (uniqueCheckString(playerNum)) {
				System.out.println("⇒ユニークです。\n");
				break;
			} else {
				System.out.println("⇒重複しています。\n");
			}
		}

		//scのclose
		sc.close();

		//終了メッセージを表示
		System.out.println("---野球ゲームプログラム終了---\n");

	}

	static boolean uniqueCheck(int[] answer) {

		//ユニークか重複かをmainメソッドに伝える変数の宣言と初期化
		boolean uniq = true;

		//重複している場合、この処理でfalseになる
		if (answer[0] == answer[1] || answer[0] == answer[2] || answer[1] == answer[2]) {
			uniq = false;
		}

		return uniq;

	}

	static boolean uniqueCheckString(String[] playerNum) {

		//ユニークか重複かをmainメソッドに伝える変数の宣言と初期化
		boolean uniqS = true;

		//重複している場合、この処理でfalseになる
		if (playerNum[0].equals(playerNum[1]) || playerNum[0].equals(playerNum[2])
				|| playerNum[1].equals(playerNum[2])) {
			uniqS = false;
		}

		return uniqS;

	}
}
