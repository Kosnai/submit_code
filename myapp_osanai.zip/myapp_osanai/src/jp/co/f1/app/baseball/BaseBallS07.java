/*
 * プログラム名 : 野球ゲームプログラムStep7
 * プログラムの説明 ： 自動で生成された正解配列とユーザーが入力した配列を比較し、
 *                     桁が異なるが数値が同じ場合にボールとしてカウントする。
 *                     なお、この処理はユーザーが入力した値がユニークの時のみ行われる。
 * 作成者 : 小山内滉貴
 * 作成日 : 2024年4月17日
 */
package jp.co.f1.app.baseball;

import java.util.Scanner;

public class BaseBallS07 {

	public static void main(String[] args) {

		//開始メッセージを表示
		System.out.println("---野球ゲームプログラム開始---\n");

		//ランダムな3つの数値を格納する配列の宣言
		int[] answer = new int[3];
		int[] playerNum = new int[3];

		//キーボード入力準備
		Scanner sc = new Scanner(System.in);

		//試行回数を計測する変数の宣言と初期化
		int tryCount = 0;
		
		/*
		 * 3桁のランダム数値を生成するための繰り返し処理(無限ループ)
		 */
		while (true) {
			//ランダムな数字を配列に格納しつつ表示
			System.out.print("3桁のランダム数字(正解数字)は");
			for (int i = 0; i < answer.length; i++) {
				answer[i] = (int) (Math.random() * 10);
				System.out.print(answer[i]);
			}
			System.out.println("です。");

			//各桁の数字が重複しているか確認
			if (uniqueCheck(answer)) {
				System.out.println("⇒ユニークです。\n");
				break;
			} else {
				System.out.println("⇒重複しています。\n");
			}

		}

		/*
		 * 3桁の数値をユーザーに入力してもらうための繰り返し処理(無限ループ)
		 */
		while (true) {
			//試行回数
			tryCount++;

			//キーボード入力
			System.out.print("3桁の数字を入力してください＞＞");
			//入力された数値を格納する変数
			String inputNum = sc.nextLine();

			//3桁の数字を各桁に分解し、playerNumに代入。
			for (int i = 0; i < playerNum.length; i++) {
				playerNum[i] = Integer.parseInt(inputNum.substring(i, i + 1));
			}

			//各桁の数字が重複しているか確認
			if (uniqueCheck(playerNum)) {
				System.out.println("⇒ユニークです。");

				//ストライクチェックの戻り値を格納する変数
				int strikeCounter = strikeCheck(answer, playerNum);

				//ストライク判定の結果を表示
				System.out.println("判定 : " + strikeCounter + "ストライク、" + ballCheck(answer, playerNum) + "ボールです。\n");

				if (strikeCounter == 3) {
					System.out.println(tryCount + "回トライし、3桁数字を当てました。You Win!!\n");
					break;
				} else {
					continue;
				}

			} else {
				System.out.println("⇒重複しています。\n");
			}

		}

		//scのclose
		sc.close();

		//終了メッセージを表示
		System.out.println("---野球ゲームプログラム終了---");

	}

	//各桁の数字が重複しているか判定するメソッド
	static boolean uniqueCheck(int[] answer) {

		//ユニークか重複かをmainメソッドに伝える変数の宣言と初期化
		boolean uniq = true;

		//重複している場合、この処理でfalseになる
		for (int i = 0; i < answer.length; i++) {
			for (int j = 0; j < answer.length; j++) {
				if (i != j && answer[j] == answer[i]) {
					uniq = false;
				}
			}
		}

		return uniq;

	}

	//ストライク数(同じ桁の数字が一致)の計算を行うメソッド
	static int strikeCheck(int[] answer, int[] playerNum) {

		//ストライク数を格納する変数の宣言と初期化
		int strikeNum = 0;

		//ストライクかどうかチェック
		for (int i = 0; i < answer.length; i++) {

			if (playerNum[i] == answer[i]) {
				strikeNum++;
			}

		}

		return strikeNum;
	}

	//ボール数(違う桁の数字が一致)の計算を行うメソッド
	static int ballCheck(int[] answer, int[] playerNum) {

		//ボール数を格納する変数の宣言と初期化
		int ballNum = 0;

		//ボールかどうかチェック
		for (int i = 0; i < playerNum.length; i++) {
			for (int j = 0; j < answer.length; j++) {

				if (i != j) {
					if (playerNum[i] == answer[j]) {
						ballNum++;
					}
				}

			}

		}

		return ballNum;
	}
}
