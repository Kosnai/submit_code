/*
 * プログラム名 : 野球ゲームプログラムStep2
 * プログラムの説明 ： 3桁の各位の値について同じ数字があれば重複していると表示し、
 *                     同じ数字が1つも無ければユニークと表示する。
 * 作成者 : 小山内滉貴
 * 作成日 : 2024年4月17日
 */
package jp.co.f1.app.baseball;

public class BaseBallS02 {

	public static void main(String[] args) {

		//開始メッセージを表示
		System.out.println("---野球ゲームプログラム開始---\n");

		//ランダムな3つの数値を格納する配列の宣言
		int[] answer = new int[3];

		//ランダムな数字を配列に格納しつつ表示
		System.out.print("3桁のランダム数字(正解数字)は");
		for (int i = 0; i < answer.length; i++) {
			answer[i] = (int) (Math.random() * 10);
			System.out.print(answer[i]);
		}
		System.out.println("です。");
		
		//ユニークか重複しているか確認
		if(uniqueCheck(answer)) {
			System.out.println("⇒ユニークです。\n");
		}else {
			System.out.println("⇒重複しています。\n");
		}
		

		//終了メッセージを表示
		System.out.println("---野球ゲームプログラム終了---\n");

	}
	
	static boolean uniqueCheck(int[] answer) {
		
		//ユニークか重複かをmainメソッドに伝える変数の宣言と初期化
		boolean uniq=true;
		
		//重複している場合、この処理でfalseになる
		if(answer[0]==answer[1]||answer[0]==answer[2]||answer[1]==answer[2]) {
			uniq=false;
		}
		
		return uniq;
		
	}

}
