/*
 * プログラム名 : 野球ゲームプログラムStep6
 * プログラムの説明 ： 自動で生成された正解配列とユーザーが入力した配列を比較し、
 *                     桁と数値が同じ場合にストライクとし、カウントする。
 *                     3桁が一致した場合にゲームが終了される。
 * 作成者 : 小山内滉貴
 * 作成日 : 2024年4月17日
 */
package jp.co.f1.app.baseball;

import java.util.Scanner;

public class BaseBallS06 {

	public static void main(String[] args) {

		//開始メッセージを表示
		System.out.println("---野球ゲームプログラム開始---\n");

		//ランダムな3つの数値を格納する配列の宣言
		int[] answer = new int[3];
		String[] playerNum = new String[3];

		//キーボード入力準備
		Scanner sc = new Scanner(System.in);
		int inputNum;//入力された数値を格納する変数

		//トライ回数を計測する変数の宣言と初期化
		int tryCount = 0;

		//無限ループ(自動生成)
		while (true) {
			//ランダムな数字を配列に格納しつつ表示
			System.out.print("3桁のランダム数字(正解数字)は");
			for (int i = 0; i < answer.length; i++) {
				answer[i] = (int) (Math.random() * 10);
				System.out.print(answer[i]);
			}
			System.out.println("です。");

			//ユニークか重複しているか確認
			if (uniqueCheck(answer)) {
				System.out.println("⇒ユニークです。\n");
				break;
			} else {
				System.out.println("⇒重複しています。\n");
			}

		}

		while (true) {
			//トライ回数
			tryCount++;

			//無限ループ(ユーザー入力)
			while (true) {

				//キーボード入力
				System.out.print("3桁の数字を入力してください＞＞");
				inputNum = sc.nextInt();

				//3桁の数字を各桁に分解し、playerNumに代入。
				for (int i = 0; i < playerNum.length; i++) {
					playerNum[i] = Integer.toString(inputNum).substring(i, i + 1);
				}

				//ユニークか重複しているか確認
				if (uniqueCheckString(playerNum)) {
					System.out.println("⇒ユニークです。");
					break;
				} else {
					System.out.println("⇒重複しています。\n");
				}
			}

			//ストライクチェックの戻り値を格納する変数
			int strikeCounter = strikeCheck(answer, playerNum);

			//ストライク判定の結果を表示
			System.out.println("判定 : " + strikeCounter + "ストライクです。\n");

			if (strikeCounter == 3) {
				System.out.println(tryCount + "回トライし、3桁数字を当てました。You Win!!\n");
				break;
			}
		}
		//scのclose
		sc.close();

		//終了メッセージを表示
		System.out.println("---野球ゲームプログラム終了---");

	}

	static boolean uniqueCheck(int[] answer) {

		//ユニークか重複かをmainメソッドに伝える変数の宣言と初期化
		boolean uniq = true;

		//重複している場合、この処理でfalseになる
		if (answer[0] == answer[1] || answer[0] == answer[2] || answer[1] == answer[2]) {
			uniq = false;
		}

		return uniq;

	}

	static boolean uniqueCheckString(String[] playerNum) {

		//ユニークか重複かをmainメソッドに伝える変数の宣言と初期化
		boolean uniqS = true;

		//重複している場合、この処理でfalseになる
		if (playerNum[0].equals(playerNum[1]) || playerNum[0].equals(playerNum[2])
				|| playerNum[1].equals(playerNum[2])) {
			uniqS = false;
		}

		return uniqS;

	}

	static int strikeCheck(int[] answer, String[] playerNum) {

		//ストライク数を格納する変数の宣言と初期化
		int strikeNum = 0;

		//ストライクかどうかチェック
		for (int i = 0; i < answer.length; i++) {

			if (playerNum[i].equals(Integer.toString(answer[i]))) {
				strikeNum++;
			}

		}

		return strikeNum;
	}
}
