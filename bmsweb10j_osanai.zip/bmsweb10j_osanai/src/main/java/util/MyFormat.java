package util;

import java.text.NumberFormat;

public class MyFormat {
	//金額データを「\付きで、3桁カンマ区切り」にするインスタンスメソッド
	public String moneyFormat(int price) {
		
		//NumberFormatクラスの宣言
		NumberFormat forM = NumberFormat.getCurrencyInstance();
		
		//変換した値を返す
		return forM.format(price);
	}
}
