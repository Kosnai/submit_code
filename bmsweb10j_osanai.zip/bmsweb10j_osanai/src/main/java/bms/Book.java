package bms;

/*
 * プログラム名：Book
 * プログラムの説明： 書籍のデータを取り扱うためクラスです。
 *                    また各変数はprivateにし、アクセサメソッドを用いて値の代入などを行っています。   
 * 作成者：小山内滉貴
 * 作成日：
 */

public class Book {
	//書籍番号を格納する変数
	private String isbn;

	//タイトルを格納する変数
	private String title;

	//価格を格納する変数
	private int price;

	/*
	 * isbnのアクセサメソッドを定義
	 */
	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	/*
	 * titleのアクセサメソッドを定義
	 */
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	/*
	 * priceのアクセサメソッドを定義
	 */
	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
}
