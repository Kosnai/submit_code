package bms;

/*
 * プログラム名：SearchServlet
 * プログラムの説明：データベース内にある書籍データの中で、
 * 					 ユーザーが入力したisbnやtitle、priceに該当する書籍データを画面に表示するサーブレットです。
 * 作成者：小山内滉貴
 * 作成日：2024/05/08
 */

import java.io.IOException;
import java.util.ArrayList;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/SearchServlet")
public class SearchServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//エラーメッセージとcmdを格納する変数
		String errorMessage = null;
		String errorCmd = null;

		try {
			//BookDAOクラスのオブジェクトを生成
			BookDAO bookDao = new BookDAO();

			//画面から送信されるisbnとtitleとpriceを取得する
			String isbn = request.getParameter("isbn");
			String title = request.getParameter("title");
			String price = request.getParameter("price");

			//検索した書籍情報を登録するArrayListオブジェクトを生成し、データを取得
			ArrayList<Book> list = bookDao.search(isbn, title, price);

			//リクエストスコープへデータを登録する
			request.setAttribute("book_list", list);

		} catch (Exception e) {
			/*
			 * DB接続エラー
			 */

			//エラーメッセージを設定
			errorMessage = "DB接続エラーのため、一覧表示は行えませんでした。";

			//errorCmdに値を登録
			errorCmd = "menu";

		} finally {
			if (errorCmd == null) {
				//list.jspへフォワードする
				request.getRequestDispatcher("/view/list.jsp").forward(request, response);
			} else {
				//リクエストスコープにエラーメッセージを登録する
				request.setAttribute("error_message", errorMessage);

				//リクエストスコープにcmdを登録する
				request.setAttribute("cmd", errorCmd);

				//error.jspへフォワードする
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}

	}
}